#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "min.h"

/* Print the usage statement.
 * minls and minget have the same usage statement, 
 * except for the first line. */
void print_usage(char *argv[])
{
   if (!strcmp(argv[0], "./minls"))
   {
      printf("usage: minls [ -v ] [ -p num [ -s num ] ] imagefile [path]\n");
   }
   else if (!strcmp(argv[0], "./minget"))
   {
      printf("usage: minget [ -v ] [ -p part [ -s subpart ] ] imagefile ");
      printf("srcpath [ dstpath ]");
   }
   printf("Options:\n");
   printf("-p part    --- select partition for filesystem (default: none)\n");
   printf("-s sub     --- select subpartition for filesystem (default: none)");
   printf("\n");
   printf("-h help    --- print usage information and exit\n");
   printf("-v verbose --- increase verbosity level\n");
}

/* Sets the flags, image_file, src_path, and dst_path 
 * based on the cmd line args. */
int parse_cmd_line(int argc, char *argv[])
{
   int opt;
   int count = 0;
   int flags;
   
   /* Set all the flags to false to start */
   p_flag = FALSE;
   s_flag = FALSE;
   h_flag = FALSE;
   v_flag = FALSE;
   
   /* Primary and sub partitions initialize to 0 and remain 0 if the
    * following arg of '-p' or '-s' is invalid or does not exist */
   prim_part = 0;
   sub_part = 0;
   
   /* Set all the specified flags from the cmd line.
    * Also set prim_part and sub_part if '-p' or '-s' is set */
   while ((opt = getopt(argc, argv, "p:s:hv")) != -1)
   {
      count++;
      switch (opt) 
      {
         case 'p':
            count++;
            p_flag = TRUE;
            prim_part = atoi(optarg);
            break;
         case 's':
            count++;
            s_flag = TRUE;
            sub_part = atoi(optarg);
            break;
         case 'h':
            h_flag = TRUE;
            print_usage(argv);
            exit(ERROR);
         case 'v':
            v_flag = TRUE;
            break;
         default:
            print_usage(argv);
            exit(ERROR);
      }
   }

   /* getopt orders the remaining args at the back of argv. 
    * The remaining args will be used for image_file, src_path, and dst_path */
   flags = count;
   count++;
   while (count <= argc)
   {
      int arg = count - flags;
      if (arg == 1)
      {
         image_file = argv[count];
      }
      else if (arg == 2)
      {
         src_path = argv[count];
      }
      else if (arg == 3)
      {
         dst_path = argv[count];
      }
      count++;
   }
   
   return SUCCESS;
}

struct superblock get_super_block(FILE *fd)
{
   char buffer[1024];
   int i;
   struct superblock sb;
      printf("hi%d %d\n\n", sizeof(struct superblock), fd);

   if (read(fd, buffer, 1024) == -1)
   {
      perror("read");
      exit(ERROR);
   }
         
   if (read(fd, &sb, sizeof(struct superblock)) == -1)
   {
      perror("read");
      exit(ERROR);
   }
   
   if (read(fd, buffer, 1024 - sizeof(struct superblock)) == -1)
   {
      perror("read");
      exit(ERROR);
   }
      
   return sb;
}

void print_super_block(struct superblock sb)
{
   printf("Superblock Contents:\n");
   printf("Stored Fields:\n");
   printf("  ninodes        %d\n", sb.ninodes);
   printf("  i_blocks       %d\n", sb.i_blocks);
   printf("  z_blocks       %d\n", sb.z_blocks);
   printf("  firstdata      %d\n", sb.firstdata);
   printf("  log_zone_size  %d (zone size: %d)\n", sb.log_zone_size, sb.blocksize);
   printf("  max_file       %lu\n", sb.max_file);
   printf("  magic          0x%04x\n", sb.magic);
   printf("  zones          %d\n", sb.zones);
   printf("  blocksize      %d\n", sb.blocksize);
   printf("  subversion     %d\n", sb.subversion);
}