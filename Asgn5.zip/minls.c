#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include "min.h"

int main(int argc, char *argv[])
{
   int i;
   FILE *image_file_fd;
   struct superblock sb;
   
   if (argc < 2)
   {
      print_usage(argv);
      return SUCCESS;
   }
   
   parse_cmd_line(argc, argv);
      
   printf("p flag: %hu | prim_part = %d\n", p_flag, prim_part);
   printf("s flag: %hu | sub_part  = %d\n", s_flag, sub_part);
   printf("h flag: %hu\n", h_flag);
   printf("v flag: %hu\n\n", v_flag);
   
   printf("image_file: %s\n", image_file);
   printf("src_path: %s\n", src_path);
   printf("dst_path: %s\n\n", dst_path);
      
   if ((image_file_fd = open(image_file, O_RDONLY)) == -1)
   {
      perror("open");
      exit(ERROR);
   }
   
   printf("fd: %d\n", (int) image_file_fd);
   
/*    if ((fread(&i, sizeof(int), 1, image_file_fd)) != 1)
   {
      perror("fread");
      exit(ERROR);
   } */
   
   sb = get_super_block(image_file_fd);
   
   print_super_block(sb);
   
   return SUCCESS;
}


